/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'vi', {
	copy: 'Bản quyền &copy; $1. Giữ toàn quyền.',
	dlgTitle: 'Thông tin về CKEditor 4',
	moreInfo: 'Vui lòng ghé thăm trang web của chúng tôi để có thông tin về giấy phép:'
} );
