/*
 Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'ja', {
	embeddingInProgress: '貼り付けられたURLを埋め込み中...',
	embeddingFailed: 'このURLは自動的に埋め込むことが出来ません。'
} );
