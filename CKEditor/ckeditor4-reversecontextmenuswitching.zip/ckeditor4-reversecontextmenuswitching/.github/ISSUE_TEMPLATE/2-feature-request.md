---
name: "⭐ Feature request"
about: Propose something new.
title: ''
labels: type:feature
assignees: ''

---

## Type of report

Feature request

## Provide description of the new feature

*What is the expected behavior of the proposed feature?*
