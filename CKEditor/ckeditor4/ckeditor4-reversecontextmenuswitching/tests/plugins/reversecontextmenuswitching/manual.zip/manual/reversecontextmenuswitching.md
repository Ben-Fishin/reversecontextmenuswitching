@bender-tags: 4.5.0, enhancement
@bender-ui: collapsed
@bender-ckeditor-plugins: wysiwygarea, toolbar, elementspath, resize

This test checks whether, when a word is mispelled, that when right clicking, suggestions will appear.

1. Misspell word.
2. Right click.
3. Locate correctly spelled word.
4. Choose correctly splled word.

**Expected result:** After choosing correctly spelled word, spell check disappears.